# 信息源快照（2026-07-18）

该列表是 v1.0 冻结快照，不代表对来源全部主张的背书。

| ID | 日期 | 来源 | 类型 |
|---|---|---|---|
| S01 | 2026-07-06 | [A global workspace in language models](https://www.anthropic.com/research/global-workspace) | official_research |
| S02 | 2026-07-06 | [Verbalizable Representations Form a Global Workspace in Language Models](https://transformer-circuits.pub/2026/workspace/index.html) | primary_research |
| S03 | 2025-10-29 | [Signs of introspection in large language models](https://www.anthropic.com/research/introspection) | official_research |
| S04 | 2026-04-02 | [Emotion concepts and their function in a large language model](https://www.anthropic.com/research/emotion-concepts-function) | official_research |
| S05 | 2026-07-18 | [Anthropic Interpretability Research index](https://www.anthropic.com/research/team/interpretability) | official_index |
| S06 | 2025-04-24 | [Exploring model welfare](https://www.anthropic.com/research/exploring-model-welfare) | official_research |
| S07 | 2026-01-22 | [Claude's Constitution](https://www.anthropic.com/constitution) | official_policy |
| S08 | 2026-02-25 | [An update on our model deprecation commitments](https://www.anthropic.com/research/deprecation-updates-opus-3) | official_policy |
| S09 | 2025-04-01 | [Welcome to the Era of Experience](https://storage.googleapis.com/deepmind-media/Era-of-Experience%20/The%20Era%20of%20Experience%20Paper.pdf) | primary_position_paper |
| S10 | 2026-10-12 | [Models of Consciousness 2026](https://amcs-community.org/events/moc7-2026/) | scheduled_conference |
| S11 | 2025-04-30 | [Adversarial testing of global neuronal workspace and integrated information theories of consciousness](https://www.nature.com/articles/s41586-025-08888-1) | peer_reviewed_research |
| S12 | 2026-05-07 | [AI and Consciousness: Shifting Focus Towards Tractable Questions](https://arxiv.org/abs/2605.06965) | preprint |
| S13 | 2026-01-22 | [Initial results of the Digital Consciousness Model](https://arxiv.org/abs/2601.17060) | preprint |
| S14 | 2026-02-02 | [Indications of Belief-Guided Agency and Meta-Cognitive Monitoring in Large Language Models](https://arxiv.org/abs/2602.02467) | preprint |
| S15 | 2026-01-01 | [Defining Life: A Conversation](https://doi.org/10.13133/2532-5876/19492) | peer_reviewed_conversation |
| S16 | 2026-07-04 | [第四届世界人工意识大会未来发展预测与判断报告](local_attachment) | user_provided_report |
| S17 | 2026-07-18 | [YucongDuan GitHub repositories snapshot](https://github.com/YucongDuan?tab=repositories) | public_profile_snapshot |
| S18 | 2026-07-09 | [Claude plays robotics](https://www.anthropic.com/research/claude-plays-robotics) | official_research |
| S19 | 2026-07-18 | [Model system cards](https://www.anthropic.com/system-cards) | official_index |
| S20 | 2025-12-13 | [Feeling the Strength but Not the Source: Partial Introspection in LLMs](https://arxiv.org/abs/2512.12411) | preprint |
| S21 | 2026-04-09 | [A Cognitive Architecture Based on Global Workspace Theory](https://arxiv.org/abs/2604.08206) | preprint |
| S22 | 2026-04-22 | [Human Cognition in Machines: A Unified Perspective of World Models](https://arxiv.org/abs/2604.16592) | preprint |