from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import save_json, sha256_obj, utcnow_iso


GENESIS = "0" * 64


def append_update(ledger_path: str | Path, event: dict[str, Any]) -> dict[str, Any]:
    path = Path(ledger_path)
    if path.exists():
        ledger = __import__("json").loads(path.read_text(encoding="utf-8"))
    else:
        ledger = {"ledger_id": "AC12-UPDATE-LEDGER", "events": [], "head_hash": GENESIS}
    payload = dict(event)
    payload.setdefault("timestamp", utcnow_iso())
    payload["previous_hash"] = ledger.get("head_hash", GENESIS)
    payload_no_hash = dict(payload)
    payload_no_hash.pop("record_hash", None)
    payload["record_hash"] = sha256_obj(payload_no_hash)
    ledger["events"].append(payload)
    ledger["head_hash"] = payload["record_hash"]
    save_json(path, ledger)
    return payload


def verify_update_ledger(ledger: dict[str, Any]) -> tuple[bool, str]:
    """Verify either an append-only update ledger or the frozen v1 forecast ledger.

    Update ledgers are hash chains over ``events``.  The frozen forecast ledger is a
    versioned envelope whose ``head_hash`` is the canonical hash of the complete
    ``forecasts`` array.  Supporting both forms keeps the CLI simple while making
    the distinction explicit in the returned message.
    """
    if "forecasts" in ledger and "events" not in ledger:
        forecasts = ledger.get("forecasts", [])
        if ledger.get("forecast_count", len(forecasts)) != len(forecasts):
            return False, "forecast_count mismatch"
        expected = sha256_obj(forecasts)
        if ledger.get("head_hash") != expected:
            return False, "frozen forecast hash mismatch"
        return True, "ok: frozen forecast ledger"

    previous = GENESIS
    for idx, event in enumerate(ledger.get("events", [])):
        if event.get("previous_hash") != previous:
            return False, f"event {idx}: previous_hash mismatch"
        payload = dict(event)
        observed = payload.pop("record_hash", None)
        expected = sha256_obj(payload)
        if observed != expected:
            return False, f"event {idx}: record_hash mismatch"
        previous = observed
    if ledger.get("head_hash", GENESIS) != previous:
        return False, "head_hash mismatch"
    return True, "ok: update ledger"
