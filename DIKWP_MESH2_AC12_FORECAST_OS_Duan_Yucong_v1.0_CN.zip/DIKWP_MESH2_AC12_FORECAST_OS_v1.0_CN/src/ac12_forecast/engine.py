from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date
from typing import Any, Iterable

from .utils import logistic, logit, parse_date


@dataclass(frozen=True)
class UpdateConfig:
    evidence_scale: float = 1.35
    half_life_days: float = 180.0
    max_abs_delta_logodds: float = 1.35
    domain_match_bonus: float = 1.0
    cross_domain_weight: float = 0.35
    min_probability: float = 0.005
    max_probability: float = 0.995


def age_decay(signal_date: date, as_of: date, half_life_days: float) -> float:
    days = max((as_of - signal_date).days, 0)
    return 0.5 ** (days / max(half_life_days, 1.0))


def signal_logodds_delta(signal: dict[str, Any], forecast_domain: str, as_of: date, config: UpdateConfig) -> float:
    same_domain = signal.get("domain") == forecast_domain
    domain_weight = config.domain_match_bonus if same_domain else config.cross_domain_weight
    raw = (
        int(signal["direction"])
        * float(signal["magnitude"])
        * float(signal["reliability"])
        * float(signal["independence"])
        * float(signal["novelty"])
        * age_decay(parse_date(signal["date"]), as_of, config.half_life_days)
        * domain_weight
        * config.evidence_scale
    )
    return max(-config.max_abs_delta_logodds, min(config.max_abs_delta_logodds, raw))


def update_probability(
    prior: float,
    forecast_domain: str,
    signals: Iterable[dict[str, Any]],
    as_of: date,
    config: UpdateConfig | None = None,
) -> tuple[float, list[dict[str, Any]]]:
    config = config or UpdateConfig()
    total = logit(prior)
    components: list[dict[str, Any]] = []
    for signal in sorted(signals, key=lambda x: (x["date"], x["signal_id"])):
        delta = signal_logodds_delta(signal, forecast_domain, as_of, config)
        total += delta
        components.append({"signal_id": signal["signal_id"], "delta_logodds": round(delta, 8)})
    posterior = logistic(total)
    posterior = min(max(posterior, config.min_probability), config.max_probability)
    return round(posterior, 6), components


def apply_scenario_probability(prior: float, additive_probability_delta: float) -> float:
    """Scenario impacts are deliberately transparent probability-point shifts, capped."""
    return round(min(max(prior + additive_probability_delta, 0.005), 0.995), 6)


def mesh_quality_score(forecast: dict[str, Any], transforms: list[dict[str, Any]]) -> dict[str, float]:
    required = set(forecast.get("mesh_transform_requirements", []))
    available = {f"{t['from']}→{t['to']}" for t in transforms}
    coverage = len(required & available) / max(len(required), 1)
    falsifiability = 1.0 if forecast.get("resolution_rule_cn") and forecast.get("falsifiers_cn") else 0.0
    evidence = min(len(forecast.get("evidence_for", [])) / 3.0, 1.0)
    observer = min(len(forecast.get("observer_index", [])) / 3.0, 1.0)
    total = 0.35 * coverage + 0.30 * falsifiability + 0.20 * evidence + 0.15 * observer
    return {
        "transform_coverage": round(coverage, 4),
        "falsifiability": round(falsifiability, 4),
        "evidence_density": round(evidence, 4),
        "observer_indexing": round(observer, 4),
        "mesh_quality": round(total, 4),
    }
