"""DIKWP-MESH² AC-12 forecasting reference runtime."""
__version__ = "1.0.0"
