from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

from .engine import UpdateConfig, mesh_quality_score, update_probability
from .ledger import append_update, verify_update_ledger
from .scoring import calibration_bins, score_set
from .utils import load_json, save_json, sha256_obj, utcnow_iso


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def cmd_validate(args: argparse.Namespace) -> int:
    root = Path(args.root or project_root())
    forecasts = load_json(root / "data/forecasts_v1.json")
    signals = load_json(root / "data/signals_seed.json")
    transforms = load_json(root / "data/mesh_transforms.json")
    frozen_ledger = load_json(root / "data/forecast_ledger_v1.json")
    fschema = load_json(root / "schemas/forecast.schema.json")
    sschema = load_json(root / "schemas/signal.schema.json")
    fv = Draft202012Validator(fschema, format_checker=FormatChecker())
    sv = Draft202012Validator(sschema, format_checker=FormatChecker())
    errors=[]
    for f in forecasts:
        errors += [f"{f['forecast_id']}: {e.message}" for e in fv.iter_errors(f)]
    for s in signals:
        errors += [f"{s['signal_id']}: {e.message}" for e in sv.iter_errors(s)]
    if len(transforms) != 25:
        errors.append(f"mesh transforms expected 25, got {len(transforms)}")
    if frozen_ledger.get("forecasts") != forecasts:
        errors.append("frozen forecast ledger does not match forecasts_v1.json")
    ledger_ok, ledger_message = verify_update_ledger(frozen_ledger)
    if not ledger_ok:
        errors.append(f"frozen ledger invalid: {ledger_message}")
    ids={f['forecast_id'] for f in forecasts}
    if len(ids)!=len(forecasts):
        errors.append("duplicate forecast_id")
    if errors:
        print("VALIDATION FAILED")
        print("\n".join(errors))
        return 1
    qualities=[mesh_quality_score(f, transforms)["mesh_quality"] for f in forecasts]
    print(json.dumps({
        "status":"PASS","forecast_count":len(forecasts),"signal_count":len(signals),"transform_count":len(transforms),
        "mean_mesh_quality":round(sum(qualities)/len(qualities),4),"forecast_hash":sha256_obj(forecasts),
        "ledger_status":ledger_message
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_update(args: argparse.Namespace) -> int:
    root = Path(args.root or project_root())
    forecasts = load_json(root / "data/forecasts_v1.json")
    signals = load_json(args.signals or root / "data/signals_seed.json")
    as_of = date.fromisoformat(args.as_of)
    domain = args.domain
    selected = [s for s in signals if s["domain"] == domain or args.include_cross_domain]
    output=[]
    ledger_path = Path(args.ledger or root / "outputs/update_ledger.json")
    for f in forecasts:
        if f["domain"] != domain:
            continue
        prior=float(f["probability"])
        posterior, components = update_probability(prior, f["domain"], selected, as_of, UpdateConfig())
        event={
            "update_id":f"UPD-{f['forecast_id']}-{args.as_of}","forecast_id":f["forecast_id"],"prior":prior,"posterior":posterior,
            "signal_ids":[x["signal_id"] for x in selected],"components":components,"method":"deterministic-log-odds-v1","as_of":args.as_of
        }
        append_update(ledger_path,event)
        output.append(event)
    print(json.dumps(output,ensure_ascii=False,indent=2))
    return 0


def cmd_verify_ledger(args: argparse.Namespace) -> int:
    ledger=load_json(args.ledger)
    ok,msg=verify_update_ledger(ledger)
    print(json.dumps({"valid":ok,"message":msg,"head_hash":ledger.get("head_hash")},ensure_ascii=False,indent=2))
    return 0 if ok else 1


def cmd_score(args: argparse.Namespace) -> int:
    root=Path(args.root or project_root())
    forecasts=load_json(root/"data/forecasts_v1.json")
    settlements=load_json(args.settlements)
    result=score_set(forecasts,settlements)
    result["calibration_bins"]=calibration_bins(forecasts,settlements)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0


def cmd_snapshot(args: argparse.Namespace) -> int:
    root=Path(args.root or project_root())
    forecasts=load_json(root/"data/forecasts_v1.json")
    sources=load_json(root/"data/sources_snapshot.json")
    scenarios=load_json(root/"data/scenarios.json")
    transforms=load_json(root/"data/mesh_transforms.json")
    snapshot={
        "snapshot_id":"AC12-SNAPSHOT-20260718-v1.0","created_at":"2026-07-18T00:00:00Z",
        "horizon":{"start":"2026-07-18","end":"2027-07-18"},
        "forecast_count":len(forecasts),"source_count":len(sources),"scenario_count":len(scenarios),"transform_count":len(transforms),
        "forecasts":forecasts,"scenarios":scenarios,
        "hashes":{"forecasts":sha256_obj(forecasts),"sources":sha256_obj(sources),"scenarios":sha256_obj(scenarios),"transforms":sha256_obj(transforms)}
    }
    snapshot["snapshot_hash"]=sha256_obj(snapshot)
    out=Path(args.out or root/"outputs/reference_snapshot.json")
    save_json(out,snapshot)
    print(json.dumps({"out":str(out),"snapshot_hash":snapshot["snapshot_hash"]},ensure_ascii=False,indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p=argparse.ArgumentParser(prog="ac12-forecast",description="DIKWP-MESH² AC-12 deterministic forecasting reference runtime")
    p.add_argument("--root",default=None)
    sub=p.add_subparsers(dest="command",required=True)
    v=sub.add_parser("validate"); v.set_defaults(func=cmd_validate)
    u=sub.add_parser("update"); u.add_argument("--domain",required=True); u.add_argument("--signals"); u.add_argument("--as-of",required=True); u.add_argument("--include-cross-domain",action="store_true"); u.add_argument("--ledger"); u.set_defaults(func=cmd_update)
    l=sub.add_parser("verify-ledger"); l.add_argument("--ledger",required=True); l.set_defaults(func=cmd_verify_ledger)
    s=sub.add_parser("score"); s.add_argument("--settlements",required=True); s.set_defaults(func=cmd_score)
    sn=sub.add_parser("snapshot"); sn.add_argument("--out"); sn.set_defaults(func=cmd_snapshot)
    return p


def main() -> int:
    args=build_parser().parse_args()
    return args.func(args)

if __name__ == "__main__":
    raise SystemExit(main())
