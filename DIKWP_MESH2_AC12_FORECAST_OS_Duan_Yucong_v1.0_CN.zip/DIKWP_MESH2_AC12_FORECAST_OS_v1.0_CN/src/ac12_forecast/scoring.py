from __future__ import annotations

import math
from typing import Any


def brier_score(probability: float, outcome: int) -> float:
    return (float(probability) - int(outcome)) ** 2


def log_score(probability: float, outcome: int) -> float:
    p = min(max(float(probability), 1e-12), 1 - 1e-12)
    return -math.log(p if int(outcome) == 1 else 1 - p)


def score_set(forecasts: list[dict[str, Any]], settlements: list[dict[str, Any]]) -> dict[str, Any]:
    p_by_id = {f["forecast_id"]: float(f["probability"]) for f in forecasts}
    rows = []
    for s in settlements:
        if s["outcome"] == "VOID":
            continue
        fid = s["forecast_id"]
        p = p_by_id[fid]
        y = int(s["outcome"])
        rows.append({
            "forecast_id": fid,
            "probability": p,
            "outcome": y,
            "brier": round(brier_score(p, y), 8),
            "log_score": round(log_score(p, y), 8),
        })
    if not rows:
        return {"count": 0, "mean_brier": None, "mean_log_score": None, "rows": []}
    return {
        "count": len(rows),
        "mean_brier": round(sum(r["brier"] for r in rows) / len(rows), 8),
        "mean_log_score": round(sum(r["log_score"] for r in rows) / len(rows), 8),
        "rows": rows,
    }


def calibration_bins(forecasts: list[dict[str, Any]], settlements: list[dict[str, Any]], bins: int = 10) -> list[dict[str, Any]]:
    outcomes = {s["forecast_id"]: s["outcome"] for s in settlements if s["outcome"] != "VOID"}
    buckets = [[] for _ in range(bins)]
    for f in forecasts:
        fid = f["forecast_id"]
        if fid not in outcomes:
            continue
        p = float(f["probability"])
        i = min(int(p * bins), bins - 1)
        buckets[i].append((p, int(outcomes[fid])))
    result=[]
    for i, bucket in enumerate(buckets):
        if bucket:
            result.append({
                "bin_low": i / bins,
                "bin_high": (i + 1) / bins,
                "count": len(bucket),
                "mean_probability": round(sum(p for p,_ in bucket)/len(bucket), 6),
                "observed_frequency": round(sum(y for _,y in bucket)/len(bucket), 6),
            })
    return result
