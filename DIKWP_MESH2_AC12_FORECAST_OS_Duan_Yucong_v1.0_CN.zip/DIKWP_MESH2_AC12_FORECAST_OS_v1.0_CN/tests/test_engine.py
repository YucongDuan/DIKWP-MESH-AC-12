from datetime import date

from ac12_forecast.engine import UpdateConfig, update_probability, apply_scenario_probability, mesh_quality_score
from ac12_forecast.utils import load_json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_update_is_deterministic():
    forecasts = load_json(ROOT / 'data/forecasts_v1.json')
    signals = load_json(ROOT / 'data/signals_seed.json')
    f = forecasts[1]
    selected = [s for s in signals if s['domain'] == f['domain']]
    a = update_probability(f['probability'], f['domain'], selected, date(2026, 8, 31))
    b = update_probability(f['probability'], f['domain'], list(reversed(selected)), date(2026, 8, 31))
    assert a == b


def test_positive_signal_raises_probability():
    prior = 0.5
    signal = {'signal_id':'x','date':'2026-07-18','domain':'d','direction':1,'magnitude':1,'reliability':1,'independence':1,'novelty':1}
    posterior, _ = update_probability(prior, 'd', [signal], date(2026, 7, 18), UpdateConfig())
    assert posterior > prior


def test_negative_signal_lowers_probability():
    prior = 0.5
    signal = {'signal_id':'x','date':'2026-07-18','domain':'d','direction':-1,'magnitude':1,'reliability':1,'independence':1,'novelty':1}
    posterior, _ = update_probability(prior, 'd', [signal], date(2026, 7, 18), UpdateConfig())
    assert posterior < prior


def test_probability_bounds():
    assert apply_scenario_probability(0.99, 0.2) == 0.995
    assert apply_scenario_probability(0.01, -0.2) == 0.005


def test_mesh_quality_high():
    forecasts = load_json(ROOT / 'data/forecasts_v1.json')
    transforms = load_json(ROOT / 'data/mesh_transforms.json')
    scores = [mesh_quality_score(f, transforms)['mesh_quality'] for f in forecasts]
    assert min(scores) >= 0.8
