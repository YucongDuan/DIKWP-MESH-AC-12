from pathlib import Path
from ac12_forecast.ledger import append_update, verify_update_ledger
from ac12_forecast.scoring import brier_score, log_score, score_set
from ac12_forecast.utils import load_json

ROOT=Path(__file__).resolve().parents[1]


def test_ledger_append_and_verify(tmp_path):
    path=tmp_path/'ledger.json'
    append_update(path, {'update_id':'u1','forecast_id':'AC12-F01','prior':0.5,'posterior':0.6,'signal_ids':['s1'],'method':'test'})
    append_update(path, {'update_id':'u2','forecast_id':'AC12-F02','prior':0.6,'posterior':0.7,'signal_ids':['s2'],'method':'test'})
    ledger=load_json(path)
    ok,msg=verify_update_ledger(ledger)
    assert ok, msg


def test_ledger_tamper_detected(tmp_path):
    path=tmp_path/'ledger.json'
    append_update(path, {'update_id':'u1','forecast_id':'AC12-F01','prior':0.5,'posterior':0.6,'signal_ids':['s1'],'method':'test'})
    ledger=load_json(path)
    ledger['events'][0]['posterior']=0.99
    ok,_=verify_update_ledger(ledger)
    assert not ok


def test_scores():
    assert brier_score(0.8,1) < brier_score(0.6,1)
    assert log_score(0.8,1) < log_score(0.6,1)


def test_score_set():
    forecasts=load_json(ROOT/'data/forecasts_v1.json')
    settlements=[{'forecast_id':'AC12-F13','outcome':1},{'forecast_id':'AC12-F01','outcome':1}]
    result=score_set(forecasts,settlements)
    assert result['count']==2
    assert result['mean_brier'] is not None


def test_frozen_forecast_ledger_verifies():
    ledger=load_json(ROOT/'data/forecast_ledger_v1.json')
    ok,msg=verify_update_ledger(ledger)
    assert ok, msg
