from pathlib import Path
from datetime import date
from jsonschema import Draft202012Validator, FormatChecker
from ac12_forecast.utils import load_json

ROOT = Path(__file__).resolve().parents[1]


def test_forecast_schema():
    forecasts=load_json(ROOT/'data/forecasts_v1.json')
    schema=load_json(ROOT/'schemas/forecast.schema.json')
    v=Draft202012Validator(schema, format_checker=FormatChecker())
    errors=[e for f in forecasts for e in v.iter_errors(f)]
    assert not errors


def test_signal_schema():
    signals=load_json(ROOT/'data/signals_seed.json')
    schema=load_json(ROOT/'schemas/signal.schema.json')
    v=Draft202012Validator(schema, format_checker=FormatChecker())
    errors=[e for s in signals for e in v.iter_errors(s)]
    assert not errors


def test_exact_25_transforms():
    transforms=load_json(ROOT/'data/mesh_transforms.json')
    pairs={(t['from'],t['to']) for t in transforms}
    assert len(transforms)==25
    assert len(pairs)==25
    for r in 'DIKWP':
        assert sum(1 for a,b in pairs if a==r)==5
        assert sum(1 for a,b in pairs if b==r)==5


def test_forecast_ids_unique_and_horizon():
    forecasts=load_json(ROOT/'data/forecasts_v1.json')
    ids=[f['forecast_id'] for f in forecasts]
    assert len(ids)==len(set(ids))==34
    start=date(2026,7,18); end=date(2027,7,18)
    for f in forecasts:
        assert date.fromisoformat(f['window_end']) <= date(2027,12,31)
        assert f['resolution_rule_cn']
        assert f['falsifiers_cn']
        assert 0 < f['probability'] < 1


def test_source_references_resolve():
    sources=load_json(ROOT/'data/sources_snapshot.json')
    source_ids={s['source_id'] for s in sources}
    forecasts=load_json(ROOT/'data/forecasts_v1.json')
    for f in forecasts:
        assert set(f['evidence_for']).issubset(source_ids)
        assert set(f['evidence_against']).issubset(source_ids)


def test_only_scheduled_forecasts_use_c1():
    forecasts=load_json(ROOT/'data/forecasts_v1.json')
    c1=[f for f in forecasts if f['certainty_class']=='C1']
    assert len(c1)==1
    assert c1[0]['forecast_id']=='AC12-F13'
