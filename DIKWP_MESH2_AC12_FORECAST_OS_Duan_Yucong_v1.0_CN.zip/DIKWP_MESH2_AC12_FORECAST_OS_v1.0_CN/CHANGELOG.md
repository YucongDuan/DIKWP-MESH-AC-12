# Changelog

## v1.0.0 — 2026-07-18

- 冻结 34 条 12 个月人工意识相关预测；
- 建立 25 类 DIKWP×DIKWP 转换；
- 建立 22 项来源快照；
- 提供确定性 log-odds 更新、追加式哈希账本、Brier/log score；
- 提供离线驾驶舱、Schema、测试和 Word 总规范。
