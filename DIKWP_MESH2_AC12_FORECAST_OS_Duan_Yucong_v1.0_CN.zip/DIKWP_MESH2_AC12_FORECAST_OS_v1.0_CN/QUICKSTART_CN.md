# 快速启动

## 1. 安装

```bash
cd DIKWP_MESH2_AC12_FORECAST_OS_v1.0_CN
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e .
```

## 2. 验证冻结预测

```bash
ac12-forecast validate
```

## 3. 生成确定性快照

```bash
ac12-forecast snapshot --out outputs/reference_snapshot.json
```

## 4. 用某一领域信号更新概率

```bash
ac12-forecast update \
  --domain workspace_replication \
  --as-of 2026-08-31 \
  --signals data/signals_seed.json \
  --ledger outputs/update_ledger.json
```

## 5. 校验追加式账本

```bash
ac12-forecast verify-ledger --ledger outputs/update_ledger.json
```

## 6. 结算与评分

创建 `settlements.json`：

```json
[
  {
    "forecast_id": "AC12-F13",
    "outcome": 1,
    "resolved_at": "2026-10-17T00:00:00Z",
    "evidence_urls": ["https://amcs-community.org/events/moc7-2026/"],
    "resolver": "independent-reviewer-01",
    "notes_cn": "会议按计划举行。"
  }
]
```

运行：

```bash
ac12-forecast score --settlements settlements.json
```

## 7. 离线驾驶舱

直接打开 `dashboard/index.html`。所有数据内嵌，不发送网络请求。
